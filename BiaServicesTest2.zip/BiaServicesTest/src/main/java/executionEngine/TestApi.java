package executionEngine;

import org.json.JSONObject;
import org.junit.Assert;

import utility.Log;

public class TestApi {

	public static JSONObject returnBody;

	public static void callLogin(String agencia, String conta, String titular,
			String tipoConta, String segmento, String nome, String cpf) {
		try {
			callServices.doLogin(agencia, conta, titular, tipoConta, segmento,
					nome, cpf, "014", "Android7.0", "sessionId", true,
					"idEquip1234", "IB", "1", "192.168.83.2|49283", "2", 66,
					"nDisSeg123", "as78jh:897fbb:sdvd907", "S", "0705",
					"1234567890");
			callServices.response.then().statusCode(200);
			Log.setPartialSuccess(callServices.response, callServices.body);
		} catch (Exception | AssertionError e) {
			EngineGeneric.bResult = false;
			Log.setError(callServices.response, null, e);
		}
	}

	public static void callDialog(String texto, String resposta) {
		try {
			callServices.postDialogo(texto, "MobTok123", 1, 0, "BR001");
			callServices.response.then().statusCode(200);
			returnBody = new JSONObject(callServices.response.jsonPath()
					.getMap("texto"));
			Assert.assertTrue(returnBody.equals(resposta));
			Log.setPartialSuccess(callServices.response, callServices.body);
		} catch (Exception | AssertionError e) {
			EngineGeneric.bResult = false;
			Log.setError(callServices.response, null, e);
		}
	}

}
