package executionEngine;

import java.io.File;

import org.apache.log4j.xml.DOMConfigurator;

import config.Constants;
import utility.Common;
import utility.ExcelUtils;
import utility.Log;

public class EngineGeneric {

	public static boolean bResult;
	public static boolean keepDialog;
	public static boolean corrupted;

	public static String parTestCaseID;
	public static String parTestCaseName;
	public static String parAgencia;
	public static String parConta;
	public static String parTitular;
	public static String parTipoConta;
	public static String parSegmento;
	public static String parNome;
	public static String parCPF;

	public static String parExecutar;
	public static String parResultado;

	public static Integer columnParam;

	public static void initialize_Test() {
		try {
			corrupted = false;
			System.setProperty("logFilePath", Constants.PathApplication);
			System.setProperty("logFileName", "logfileBia");
			DOMConfigurator.configure("log4j.xml");

			if ((new File(Constants.PathApplication).length() / 1024) > 1) {
				Common.copyFile(new File(Constants.PathApplication), new File(
						Constants.PathApplication + "/Backup/DataEngine.xlsx"));
				ExcelUtils.setExcelFile(Constants.PathApplication);
				cleanTestResults();
			} else {
				corrupted = true;
				Log.fatal("A planilha 'DataEngine.xls' foi corrompida!");
			}
		} catch (Exception e) {
			Log.error("Class EngineGeneric | Method initialize_Test | Exception desc : "
					+ e);
		}
	}

	/*
	 * Descrição: Executa a automação
	 */
	public static void execute_TestCase() {
		try {

			int iTotalTestCases = ExcelUtils
					.getRowCount(Constants.Sheet_TestCases);

			for (int iTestcase = 1; iTestcase < iTotalTestCases; iTestcase++) {

				bResult = true;
				keepDialog = true;

				parExecutar = ExcelUtils.getCellData(iTestcase,
						Constants.Col_Executar, Constants.Sheet_TestCases);

				if ("Sim".equals(parExecutar)) {
					parTestCaseID = ExcelUtils
							.getCellData(iTestcase, Constants.Col_TestCaseID,
									Constants.Sheet_TestSteps);
					parTestCaseName = ExcelUtils.getCellData(iTestcase,
							Constants.Col_TestCaseName,
							Constants.Sheet_TestSteps);
					parAgencia = ExcelUtils.getCellData(iTestcase,
							Constants.Col_Agencia, Constants.Sheet_TestSteps);
					parConta = ExcelUtils.getCellData(iTestcase,
							Constants.Col_Conta, Constants.Sheet_TestSteps);
					parTitular = ExcelUtils.getCellData(iTestcase,
							Constants.Col_Titular, Constants.Sheet_TestSteps);
					parTipoConta = ExcelUtils.getCellData(iTestcase,
							Constants.Col_TipoConta, Constants.Sheet_TestSteps);
					parSegmento = ExcelUtils.getCellData(iTestcase,
							Constants.Col_Segmento, Constants.Sheet_TestSteps);
					parNome = ExcelUtils.getCellData(iTestcase,
							Constants.Col_Nome, Constants.Sheet_TestSteps);
					parCPF = ExcelUtils.getCellData(iTestcase,
							Constants.Col_CPF, Constants.Sheet_TestSteps);

					columnParam = 3;

					Log.startTestCase(parTestCaseID, parTestCaseName);

					TestApi.callLogin(parAgencia, parConta, parTitular,
							parTipoConta, parSegmento, parNome, parCPF);

					while (keepDialog && bResult) {
						String texto = ExcelUtils.getCellData(iTestcase,
								columnParam,
								Constants.Sheet_TestCases);

						String resposta = ExcelUtils.getCellData(iTestcase,
								columnParam + 1,
								Constants.Sheet_TestCases);

						TestApi.callDialog(texto, resposta);

						columnParam = columnParam + 2;

						String nextColumn = ExcelUtils.getCellData(iTestcase,
								columnParam, Constants.Sheet_TestCases);

						if (nextColumn.isEmpty()) {
							keepDialog = false;
						}
					}

					Log.endTestCase();

					if (bResult) {
						ExcelUtils.setCellData(Constants.KEYWORD_PASS,
								iTestcase, Constants.Col_Resultado,
								Constants.Sheet_TestCases);
					} else {
						ExcelUtils.setCellData(Constants.KEYWORD_FAIL,
								iTestcase, Constants.Col_Resultado,
								Constants.Sheet_TestCases);
					}
				}
			}
		} catch (Exception e) {
			Log.error("Class EngineGeneric | Method execute_TestCase | Exception desc : "
					+ e);
		}
	}

	/*
	 * Descrição: Limpa as colunas com o resultado da execução, tempo da
	 * execução e passo que falhou
	 */
	public static void cleanTestResults() {
		try {
			ExcelUtils.clearCellResults(Constants.Col_Resultado,
					Constants.Sheet_TestCases);
		} catch (Exception e) {
			Log.error("Class EngineGeneric | Method cleanTestResults | Exception desc : "
					+ e);
			EngineGeneric.bResult = false;
		}
	}
}
