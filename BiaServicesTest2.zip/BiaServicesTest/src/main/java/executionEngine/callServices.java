package executionEngine;
import org.json.JSONObject;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import utility.Log;

public class callServices {

    public static Response response = null;
    public static String token = null;
    public static String body = null;
    public static JSONObject context = null;

    public static void doLogin(String agencia, String conta, String titularidade, String tipoConta, String segmento, String nome,
        String cpf, String codigoPeriferico, String userAgent, String sessionId, Boolean appAtualizado, String identEquipamento, 
        String codigoServico, String tipoDispSeguranca, String ipOrigem, String tipoUsuario, Integer origemLogin, 
        String numeroDispSeguranca, String numeroUnicoOperacao, String marcaDispSeguranca, String razaoCliente, String controleSessao) {
        try {
            String urlLogin = "http://172.16.43.151:8080/bia-transacional/v1/login";
            String json = "{\"agencia\":\"" + agencia + "\","
                + "\"codigoPeriferico\":\"" + codigoPeriferico + "\","
                + "\"codigoServico\":\"" + codigoServico + "\","
                + "\"conta\":\"" + conta + "\","
                + "\"controleSessao\":\"" + controleSessao + "\","
                + "\"cpfCliente\":\"" + cpf + "\","
                + "\"identEquipamento\":\"" + identEquipamento + "\","
                + "\"ipOrigem\":\"" + ipOrigem + "\","
                + "\"marcaDispSeguranca\":\"" + marcaDispSeguranca + "\","
                + "\"nomeCliente\":\"" + nome + "\","
                + "\"numeroDispSeguranca\":\"" + numeroDispSeguranca + "\","
                + "\"numeroUnicoOperacao\":\"" + numeroUnicoOperacao + "\","
                + "\"origemLogin\":" + origemLogin + ","
                + "\"razaoCliente\":\"" + razaoCliente + "\","
                + "\"segmentoCliente\":\"" + segmento + "\","
                + "\"sessionId\":\"" + sessionId + "\","
                + "\"tipoConta\":\"" + tipoConta + "\","
                + "\"tipoDispSeguranca\":\"" + tipoDispSeguranca + "\","
                + "\"tipoUsuario\":\"" + tipoUsuario + "\","
                + "\"titularidade\":\"" + titularidade + "\","
                + "\"userAgent\":\"" + userAgent + "\","
                + "\"appAtualizado\":" + appAtualizado + "}";
            RequestSpecification httpRequest = RestAssured.given();
            response = httpRequest.contentType(ContentType.JSON).body(json).when().post(urlLogin);
            token = response.jsonPath().get("token");
            context = new JSONObject(response.jsonPath().getMap("contexto"));
            body = response.getBody().asString();
        } catch (Exception e) {
            Log.error("Class callServices | Method doLogin | Exception desc : " + e);
        }
    }

    public static void postDialogo(String texto, String mobileToken, Integer dispositivoSeguranca, Integer flagDispositivoSeguranca, String modeloDipositivoSeguranca) {
        try {
            String urlLogin = "http://172.16.43.151:8080/bia-transacional/v1/dialogo";
            String json = "{\"texto\":\"" + texto + "\","
                + "\"dispositivoSegurancaInfo\": {"
                    + "\"dispositivoSeguranca\":" + dispositivoSeguranca + ","
                    + "\"flagDispositivoSeguranca\":" + flagDispositivoSeguranca + ","
                    + "\"modeloDipositivoSeguranca\":\"" + modeloDipositivoSeguranca + "\""
                + "},"
                + "\"mobileToken\":\"" + mobileToken + "\","
                + "\"contexto\": " + context + "}";

            RequestSpecification httpRequest = RestAssured.given().header("Authorization", token);
            response = httpRequest.contentType(ContentType.JSON).body(json).when().post(urlLogin);
            body = response.getBody().asString();
        } catch (Exception e) {
            Log.error("Class callServices | Method postDialogo | Exception desc : " + e);
        }
    }
}
