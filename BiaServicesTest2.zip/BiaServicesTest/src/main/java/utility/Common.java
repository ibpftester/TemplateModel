package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Common {

    private Common() {
    }

    /*
     * Descrição: Suspende a execução da aplicação temporariamente Parâmetros: milliseconds: tempo
     * em milisegundos que a aplicação ficará suspensa
     */
    public static void wait(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Log.error("Class Common | Method wait | Exception desc : " + e);
        }
    }


    /*
     * Descrição: Verifica se existe um arquivo em um diretório Parâmetros: downloadPath: diretório
     * que será verificado fileName: nome do arquivo que será verificado
     */
    public static boolean isFileDownloaded(String downloadPath, String fileName) {
        boolean flag = false;
        try {
            File dir = new File(downloadPath);
            File[] dirContents = dir.listFiles();
            for (int i = 0; i < dirContents.length; i++) {
                if (dirContents[i].getName().contains(fileName)) {
                    flag = true;
                    return flag;
                }
            }
        } catch (Exception e) {
            Log.error("Class Common | Method isFileDownloaded | Exception desc : " + e);
        }
        return flag;
    }

    /*
     * Descrição: Verifica se existe um arquivo em um diretório, em caso afirmativo o mesmo será
     * excluído Parâmetros: downloadPath: diretório que será verificado fileName: nome do arquivo
     * que será verificado/excluído
     */
    public static boolean isFileDeleted(String downloadPath, String fileName) {
        try {
            File file = new File(downloadPath + "\\" + fileName);
            if (file.exists()) {
                file.delete();
            }
            wait(3000);
        } catch (Exception e) {
            Log.error("Class Common | Method isFileDeleted | Exception desc : " + e);
        }
        return !isFileDownloaded(downloadPath, fileName);
    }

    /*
     * Descrição: Copia um arquivo (backup) para um determinado diretório. Caso já exista um arquivo
     * no diretório de destino, o mesmo é deletado e substituído pelo novo arquivo copiado.
     * Parâmetros: source: diretório do arquivo a ser copiado dest: diretório onde o arquivo copiado
     * será disponibilizado
     */
    public static void copyFile(File source, File dest) {
        try {
            String file;
            String path;

            file = dest.getAbsolutePath().substring(dest.getAbsolutePath().lastIndexOf("\\") + 1);
            path = dest.getAbsolutePath().substring(0, dest.getAbsolutePath().lastIndexOf("\\"));

            if (!new File(path).exists()) {
                new File(path).mkdir();
            }
            isFileDeleted(path, file);
            FileInputStream sourceChannel = new FileInputStream(source);
            FileOutputStream destChannel = new FileOutputStream(dest);
            destChannel.getChannel().transferFrom(sourceChannel.getChannel(), 0, sourceChannel.getChannel().size());
            sourceChannel.close();
            destChannel.close();
        } catch (Exception e) {
            Log.error("Class Common | Method copyFile | Exception desc : " + e);
        }
    }
}
