package utility;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import config.Constants;
import executionEngine.EngineGeneric;

public class ExcelUtils {

    private static XSSFSheet ExcelWSheet;
    private static XSSFWorkbook ExcelWBook;
    private static XSSFRow Row;

    /*
     * Descrição: Define um arquivo .xls através de um diretório 
     * Parâmetros: 
     *          path: diretório do arquivo onde está disponibilizado o .xls (Ex:"C:/users/path/DataEngine.xls")
     */
    public static void setExcelFile(String path) throws Exception {
        try {
            FileInputStream excelFile = new FileInputStream(path);
            ExcelWBook = new XSSFWorkbook(excelFile);
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method setExcelFile | Exception desc : " + e);
            EngineGeneric.bResult = false;
        }
    }

    /*
     * Descrição: Obtém o valor de uma célula de um arquivo .xls 
     * Parâmetros: 
     *          rowNum: número da linha da célula a ser obtida
     *          colNum: número da coluna da célula a ser obtida
     *          sheetName: nome da aba da célula a ser obtida
     */
    public static String getCellData(int rowNum, int colNum, String sheetName) throws Exception {
        try {
            ExcelWSheet = ExcelWBook.getSheet(sheetName);
            Row = ExcelWSheet.getRow(rowNum);
            FormulaEvaluator evaluator = ExcelWBook.getCreationHelper().createFormulaEvaluator();
            String cellData = "";
            if (Row != null) {
                if (Row.getCell(colNum) != null) {
                    if (Row.getCell(colNum).getCellType() == 1) {
                        cellData = Row.getCell(colNum).getStringCellValue();
                    } else if (Row.getCell(colNum).getCellType() == 0) {
                        XSSFCell xssfCell = Row.getCell(colNum);
                        xssfCell.setCellType(1);
                        cellData = xssfCell.getStringCellValue();
                    } else if (Row.getCell(colNum).getCellType() == 2) {
                        switch (evaluator.evaluateFormulaCell(Row.getCell(colNum))) {
                        case Cell.CELL_TYPE_STRING:
                            cellData = Row.getCell(colNum).getStringCellValue();
                            break;
                        case Cell.CELL_TYPE_NUMERIC:
                            cellData = String.valueOf(Row.getCell(colNum).getNumericCellValue());
                            break;
                        case Cell.CELL_TYPE_BOOLEAN:
                            cellData = String.valueOf(Row.getCell(colNum).getBooleanCellValue());
                            break;
                        case Cell.CELL_TYPE_BLANK:
                            cellData = "";
                            break;
                        default:
                            cellData = Row.getCell(colNum).getStringCellValue();
                        }
                    } else {
                        XSSFCell xssfCell = Row.getCell(colNum);
                        cellData = xssfCell.getStringCellValue();
                    }
                }
            }
            return cellData;
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method getCellData | Exception desc : " + e);
            EngineGeneric.bResult = false;
            return "";
        }
    }

    /*
     * Descrição: Obtém a quantidade de linhas preenchidas em uma aba de um arquivo .xls
     * Parâmetros: 
     *          sheetName: nome da aba a ser considerada na contagem das linhas
     */
    public static int getRowCount(String sheetName) {
        int iNumber = 0;
        XSSFSheet sheet = null;
        try {
            sheet = ExcelWBook.getSheet(sheetName);
            iNumber = sheet.getLastRowNum() + 1;
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method getRowCount | Exception desc : " + e);
            EngineGeneric.bResult = false;
        }
        return getCellsWithValue(sheet, iNumber);
    }

    /*
     * Descrição: Obtém a quantidade de linhas na aba de passos de teste do arquivo .xls
     * Parâmetros: 
     *          sheetName: nome da aba onde estão descritos os passos de teste
     */
    public static int getRowCountSteps(String sheetName) {
        int iNumber = 0;
        try {
            XSSFSheet sheet = ExcelWBook.getSheet(sheetName);
            iNumber = sheet.getLastRowNum() + 1;
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method getRowCountSteps | Exception desc : " + e);
            EngineGeneric.bResult = false;
        }
        return iNumber;
    }

    /*
     * Descrição: Obtém a linha (passo) que inicia um cenário de teste
     * Parâmetros: 
     *          sTestCaseName: nome/id do caso de teste a ser verificado
     *          colNum: número da coluna que vai ser pesquisada para verificação do valor do 'sTestCaseName'
     *          sheetName: nome da aba onde estão as informações a serem consultadas
     */
    public static int getRowContains(String sTestCaseName, int colNum, String sheetName) throws Exception {
        int iRowNum = 1;
        try {
            ExcelWSheet = ExcelWBook.getSheet(sheetName);
            int rowCount = ExcelUtils.getRowCountSteps(sheetName);
            for (; iRowNum < rowCount; iRowNum++) {
                if (ExcelUtils.getCellData(iRowNum, colNum, sheetName).equalsIgnoreCase(sTestCaseName)) {
                    break;
                }
            }
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method getRowContains | Exception desc : " + e);
            EngineGeneric.bResult = false;
        }
        return iRowNum;
    }

    /*
     * Descrição: Obtém a linha (passo) que encerra um cenário de teste
     * Parâmetros: 
     *          sheetName: nome da aba onde estão as informações a serem consultadas
     *          sTestCaseID: nome/id do caso de teste a ser verificado
     *          colNum: número da coluna que vai ser pesquisada para verificação do valor do 'sTestCaseID'
     */
    public static int getTestStepsCount(String sheetName, String sTestCaseID, int iTestCaseStart) throws Exception {
        try {
            for (int i = iTestCaseStart; i <= ExcelUtils.getRowCountSteps(sheetName); i++) {
                if (!(sTestCaseID.equals(ExcelUtils.getCellData(i, Constants.Col_TestCaseID, sheetName)))) {
                    int number = i;
                    return number;
                }
            }
            ExcelWSheet = ExcelWBook.getSheet(sheetName);
            return ExcelWSheet.getLastRowNum() + 1;
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method getTestStepsCount | Exception desc : " + e);
            EngineGeneric.bResult = false;
            return 0;
        }
    }

    /*
     * Descrição: Altera o valor de uma célula de um arquivo .xls
     * Parâmetros: 
     *          result: valor a ser registrado na célula
     *          rowNum: linha da célula a ser alterada
     *          colNum: coluna da célula a ser alterada
     *          sheetName: nome da aba onde a célula será alterada
     */
    public static void setCellData(String result, int rowNum, int colNum, String sheetName) throws Exception {
        try {
            ExcelWSheet = ExcelWBook.getSheet(sheetName);
            XSSFRow row = ExcelWSheet.getRow(rowNum);
            XSSFCell cell = row.getCell(colNum, org.apache.poi.ss.usermodel.Row.RETURN_BLANK_AS_NULL);

            if (cell == null) {
                CellStyle cellStyle = null;
                if (row.getCell(colNum) != null) {
                    cellStyle = row.getCell(colNum).getCellStyle();
                }
                cell = row.createCell(colNum);
                cell.setCellValue(result);
                if (row.getCell(colNum) != null) {
                    cell.setCellStyle(cellStyle);
                }
            } else {
                cell.setCellValue(result);
            }
            FileOutputStream fileOut = new FileOutputStream(Constants.PathApplication);
            ExcelWBook.write(fileOut);
            fileOut.flush();
            fileOut.close();
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method setCellData | Exception desc : " + e);
            EngineGeneric.bResult = false;
        }
    }

    /*
     * Descrição: Limpa as informações de uma coluna específica de um arquivo .xls
     * Parâmetros: 
     *          colNum: coluna que terão os valores das células deletados
     *          sheetName: nome da aba onde as células terão seus valores deletados
     */
    public static void clearCellResults(int colNum, String sheetName) throws Exception {
        try {
            ExcelWSheet = ExcelWBook.getSheet(sheetName);
            int rownum = ExcelWSheet.getLastRowNum();
            for (int i = 1; i < rownum + 1; i++) {
                XSSFRow row = ExcelWSheet.getRow(i);
                if (row != null) {
                    XSSFCell cell = row.getCell(colNum);
                    if (cell != null) {
                        if (cell.getCTCell().isSetT())
                            cell.getCTCell().unsetT();
                        if (cell.getCTCell().isSetV())
                            cell.getCTCell().unsetV();
                    }
                }
            }
            FileOutputStream fileOut = new FileOutputStream(Constants.PathApplication);
            ExcelWBook.write(fileOut);
            fileOut.flush();
            fileOut.close();
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method clearCellResults | Exception desc : " + e);
            EngineGeneric.bResult = false;
        }
    }

    /*
     * Descrição: Executa as células com fórmulas
     */
    public static void refreshFormulaCells() throws Exception {
        try {
            XSSFFormulaEvaluator.evaluateAllFormulaCells(ExcelWBook);
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method refreshFormulaCells | Exception desc : " + e);
            EngineGeneric.bResult = false;
        }
    }

    /*
     * Descrição: Define o tipo de uma célula alterando o valor para String em um arquivo .xls
     * Parâmetros:
     *          rowNum: linha da célula a ser alterada
     *          colNum: coluna da célula a ser alterada
     *          sheetName: nome da aba onde a célula será alterada
     */
    public static void setCellToString(int rowNum, int colNum, String sheetName) throws Exception {
        try {
            ExcelWSheet = ExcelWBook.getSheet(sheetName);
            XSSFRow row = ExcelWSheet.getRow(rowNum);
            XSSFCell cell = row.getCell(colNum);
            cell.setCellType(Cell.CELL_TYPE_STRING);
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method setCellToString | Exception desc : " + e);
            EngineGeneric.bResult = false;
        }
    }

    /*
     * Descrição: Obtém o número de linhas preenchidas em um intervalo definido
     * Parâmetros:
     *          total: número máximo de linhas a ser considerada na verificação
     *          sheet: nome da aba onde a célula será alterada
     */
    public static int getCellsWithValue(XSSFSheet sheet, int total) {
        int newTotal = total;
        try{
            for (int i = 0; i < total; i++) {
                if (sheet.getRow(i).getCell(0).getCellType() == Cell.CELL_TYPE_BLANK){
                    newTotal--;
                }
            }            
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method getCellsWithValue | Exception desc : " + e);
            EngineGeneric.bResult = false;
        }
        return newTotal;
    }
}
