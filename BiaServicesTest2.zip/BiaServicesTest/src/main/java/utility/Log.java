package utility;


import io.restassured.response.Response;

import org.apache.log4j.Logger;

public class Log {

    private static Logger Log = Logger.getLogger(Log.class.getName());

    /*
     * Descrição: Registra log de início da execução do caso de teste e define hora de início
     * Parâmetros: 
     *          sTestCaseName: nome do caso de teste em execução
     */
    public static void startTestCase(String sTestCaseID, String sTestCaseName) {
        Log.info("******************************************************************************************************");
        Log.info("******************************************************************************************************");
        Log.info(sTestCaseID + ": " + sTestCaseName);
        Log.info("******************************************************************************************************");
        Log.info("******************************************************************************************************");
        Log.info("");
    }

    /*
     * Descrição: Registra log e hora de encerramento da execução do caso de teste
     * Parâmetros: 
     *          sTestCaseName: nome do caso de teste em execução
     */
    public static void endTestCase() {
        Log.info("");
        Log.info("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX             " + "-E--N--D-" + "             XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        Log.info("X");
        Log.info("X");
        Log.info("X");
        Log.info("X");
    }

    /*
     * Descrição: Registra log de sucesso na execução do caso de teste
     * Parâmetros: 
     *          response: resposta da requisição
     *          message: texto de sucesso
     */
    public static void setSuccess(Response response, String message) {
        String codeResponse = response.getStatusLine();
        Long timeResponse = response.getTime();
        Log.info("((SUCESSO))");
        Log.info("Status: " + codeResponse);
        Log.info("Time: " + timeResponse + " ms");
        if (message != null){
            Log.info(message);
        }
        endTestCase();
    }

    /*
     * Descrição: Registra log de sucesso na execução do caso de teste
     * Parâmetros: 
     *          response: resposta da requisição
     *          message: texto de sucesso
     */
    public static void setPartialSuccess(Response response, String message) {
        String codeResponse = response.getStatusLine();
        Long timeResponse = response.getTime();
        Log.info("((SUCESSO))");
        Log.info("Status: " + codeResponse);
        Log.info("Time: " + timeResponse + " ms");
        if (message != null){
            Log.info(message);
        }
        Log.info("");
    }
    
    /*
     * Descrição: Registra log de falha na execução do caso de teste
     * Parâmetros: 
     *          response: resposta da requisição
     *          message: texto de erro
     *          e: exceção de falha
     */
    public static void setError(Response response, String message, Throwable e) {
        String codeResponse = response.getStatusLine();
        Long timeResponse = response.getTime();
        Log.info("((FALHA))");
        Log.info("Status: " + codeResponse);
        Log.info("Time: " + timeResponse + " ms");
        if (message != null){
            Log.info(message + ": " + e);
        } else {
            Log.error(e);
        }
        endTestCase();
    }

    /*
     * Descrição: Registra log informativo
     * Parâmetros: 
     *          message: informação a ser registrada no log
     */
    public static void info(String message) {
        Log.info(message);
    }

    /*
     * Descrição: Registra log de aviso
     * Parâmetros: 
     *          message: informação a ser registrada no log
     */
    public static void warn(String message) {
        Log.warn(message);
    }

    /*
     * Descrição: Registra log de erros
     * Parâmetros: 
     *          message: informação a ser registrada no log
     */
    public static void error(String message) {
        Log.error(message);
    }

    /*
     * Descrição: Registra log de falha explícita ou situação não recuperável
     * Parâmetros: 
     *          message: informação a ser registrada no log
     */
    public static void fatal(String message) {
        Log.fatal(message);
    }

    /*
     * Descrição: Registra log de debug
     * Parâmetros: 
     *          message: informação a ser registrada no log
     */
    public static void debug(String message) {
        Log.debug(message);
    }
}
