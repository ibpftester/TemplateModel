package config;


public class Constants {

    public static final String File_TestData = "DataEngine.xlsx";
    
    public static final String PathApplication = System.getProperty("user.dir");
    
    public static final int Col_TestCaseID = 0;
    public static final int Col_TestCaseName = 1;
    public static final int Col_Agencia = 2;
    public static final int Col_Conta = 3;
    public static final int Col_Titular = 4;
    public static final int Col_TipoConta = 5;
    public static final int Col_Segmento = 6;
    public static final int Col_Nome = 7;
    public static final int Col_CPF = 8;

    public static final int Col_TestCase = 0;
    public static final int Col_Executar = 1;
    public static final int Col_Resultado = 2;

    public static final String Sheet_TestSteps = "Test Steps";
    public static final String Sheet_TestCases = "Test Cases";

    public static final String KEYWORD_FAIL = "FALHA";
    public static final String KEYWORD_PASS = "SUCESSO";
}
