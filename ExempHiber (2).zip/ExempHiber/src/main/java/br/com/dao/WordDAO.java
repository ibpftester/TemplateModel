package br.com.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.com.entities.ConnectionFactory;
import br.com.entities.Word;

public class WordDAO {

    public static Word saveWord(String desc) {
        EntityManager em = new ConnectionFactory().getConnection();
        Word w = new Word();
        w.setDescription(desc);
        em.getTransaction().begin();
        em.persist(w);
        em.getTransaction().commit();
        em.close();
        
        return w;
    }
    
    public static void save(String desc, List<Word> listWord) {
        EntityManager em = new ConnectionFactory().getConnection();
        Word w;
        em.getTransaction().begin();
        if(get(desc).getId() != null){
            w = get(desc);
            w.setWordCollection(listWord);
            em.merge(w);
        } else{
            w = new Word();
            w.setDescription(desc);
            w.setWordCollection(listWord);
            em.persist(w);
        }
       
        em.getTransaction().commit();
        em.close();
    }

    public static Word get(String description) {
        EntityManager em = new ConnectionFactory().getConnection();
        em.getTransaction().begin();

        String jpql = "select p from Word p where p.description = '" + description + "'";
        TypedQuery<Word> query = em.createQuery(jpql, Word.class);
        List<Word> results = query.getResultList();

        em.getTransaction().commit();
        em.close();
        
        if(!results.isEmpty()){
            return results.get(0);    
        } else {
            return null;
        }
        
    }
    
    public static List<Word> getAllWords() {
        EntityManager em = new ConnectionFactory().getConnection();
        em.getTransaction().begin();

        String jpql = "select p from Word p";
        TypedQuery<Word> query = em.createQuery(jpql, Word.class);
        List<Word> results = query.getResultList();

        em.getTransaction().commit();
        em.close();
        
        return results;
    }

    public static List<Word> getRelationshipWord(Word word) {
        EntityManager em = new ConnectionFactory().getConnection();
        em.getTransaction().begin();

        String jpql = "select r from Relationship r";
        TypedQuery<Word> query = em.createQuery(jpql, Word.class);
        List<Word> results = query.getResultList();

        em.getTransaction().commit();
        em.close();
        
        return results;
    }
}
