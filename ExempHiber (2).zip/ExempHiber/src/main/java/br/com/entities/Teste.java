package br.com.entities;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.mysql.cj.xdevapi.JsonArray;

import br.com.dao.WordDAO;

public class Teste {

    @SuppressWarnings("unchecked")
    public static void main(String[] args) {

        List<Word> listWords = new ArrayList<Word>();
        listWords = WordDAO.getAllWords();

        JSONArray arrayNodes = new JSONArray();
        JSONArray arrayEdges = new JSONArray();
        int pos = 0;
        int idRel = 50000;

        for (int i = 0; i < listWords.size(); i++) {

            pos = pos + 25;
            Word word = listWords.get(i);

            JSONArray arrayDataNodesCytoscape = new JSONArray();
            arrayDataNodesCytoscape.add(word.getDescription());

            JSONObject objDataNodes = new JSONObject();
            objDataNodes.put("id", word.getId());
            objDataNodes.put("Strength", 5);
            objDataNodes.put("selected", false);
            objDataNodes.put("cytoscape_alias_list", arrayDataNodesCytoscape);
            objDataNodes.put("canonicalName", word.getDescription());
            objDataNodes.put("Milk", "");
            objDataNodes.put("Synonym", "");
            objDataNodes.put("Quality", 90);
            objDataNodes.put("Type", word.getDescription().substring(0,1));
            objDataNodes.put("SUID", word.getId());
            objDataNodes.put("NodeType", "");
            objDataNodes.put("name", word.getDescription());
            objDataNodes.put("Country", "");
            objDataNodes.put("shared_name", word.getDescription());

            JSONObject objPositionNodes = new JSONObject();
            objPositionNodes.put("x", 4000.9853515625 + pos);
            objPositionNodes.put("y", 4000.1904296875 + pos);

            JSONObject objUnityNodes = new JSONObject();
            objUnityNodes.put("data", objDataNodes);
            objUnityNodes.put("position", objPositionNodes);
            objUnityNodes.put("selected", false);

            arrayNodes.add(objUnityNodes);

            List<Word> collection = listWords.get(i).getWordCollection();

            for (int j = 0; j < collection.size(); j++) {
                Word wordRel = collection.get(j);

                JSONObject objDataEdges = new JSONObject();
                objDataEdges.put("id", String.valueOf(idRel));
                objDataEdges.put("source", word.getId());
                objDataEdges.put("target", wordRel.getId());
                objDataEdges.put("selected", false);
                objDataEdges.put("canonicalName", wordRel.getDescription());
                objDataEdges.put("SUID", idRel);
                objDataEdges.put("name", wordRel.getDescription());
                objDataEdges.put("interaction", "cc");
                objDataEdges.put("shared_interaction", "cc");
                objDataEdges.put("shared_name", wordRel.getDescription());

                JSONObject objUnityEdges = new JSONObject();
                objUnityEdges.put("data", objDataEdges);
                objUnityEdges.put("selected", false);

                arrayEdges.add(objUnityEdges);

                idRel++;
            }
        }

        JSONObject objArrrayElements = new JSONObject();
        objArrrayElements.put("nodes", arrayNodes);
        objArrrayElements.put("edges", arrayEdges);

        JSONObject objArrayData = new JSONObject();
        objArrayData.put("selected", true);
        objArrayData.put("__Annotations", new JsonArray());
        objArrayData.put("shared_name", "Challenge Stilingue");
        objArrayData.put("SUID", 1);
        objArrayData.put("name", "Challenge Stilingue");

        JSONObject mainObject = new JSONObject();
        mainObject.put("format_version", "1.0");
        mainObject.put("generated_by", "cytoscape-3.2.0");
        mainObject.put("target_cytoscapejs_version", "~2.1");
        mainObject.put("data", objArrayData);
        mainObject.put("elements", objArrrayElements);

        try (FileWriter file = new FileWriter("C:/Users/pguirelli/Desktop/data.json")) {
            file.write(mainObject.toJSONString());
            file.flush();
            System.out.println("Successfully Copied JSON Object to File...");
            System.out.println("\nJSON Object: " + mainObject);
        } catch (IOException e) {
            e.printStackTrace();
        }


        String[] employeeData = { "teste 9", "teste 7", "teste 10", "teste 3", "teste 4", "teste 6" };

        List<Word> teste = new ArrayList<Word>();

        for (String proj : employeeData) {
            Word waa = WordDAO.get(proj);
            if (waa != null) {
                teste.add(waa);
            } else {
                teste.add(WordDAO.saveWord(proj));
            }
        }

        WordDAO.save("teste 10", teste);

    }

}
