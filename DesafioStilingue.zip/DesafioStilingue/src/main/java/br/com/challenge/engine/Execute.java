package br.com.challenge.engine;

import br.com.challenge.connection.ConnectionFactory;
import br.com.challenge.web.crawler.GenerateJson;
import br.com.challenge.web.crawler.WebCrawler;

public class Execute {

	public static void main(String[] args) {
		WebCrawler.startWebCrawler();
		GenerateJson.generateJson();
		ConnectionFactory.closeConnection();
	}

}
