package br.com.entities;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import br.com.dao.WordDAO;

public class Teste {

    public static void main(String[] args) {
        String[] employeeData = { "testeA", "testeB", "teste 3C" };

        List<Word> teste = new ArrayList<Word>();

        for (String proj : employeeData) {
            Word waa = WordDAO.get(proj);
            if (waa != null) {
                teste.add(waa);
            } else {
                teste.add(WordDAO.saveWord(proj));
            }
        }

        WordDAO.save("testeD", teste);

    }

}
