package br.com.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.com.entities.ConnectionFactory;
import br.com.entities.Word;

public class WordDAO {

    public static Word saveWord(String desc) {
        EntityManager em = new ConnectionFactory().getConnection();
        Word w = new Word();
        w.setDescription(desc);
        em.getTransaction().begin();
        em.persist(w);
        em.getTransaction().commit();
        em.close();
        
        return w;
    }
    
    public static void save(String desc, List<Word> listWord) {
        EntityManager em = new ConnectionFactory().getConnection();
        Word w = new Word();
        w.setDescription(desc);
        w.setWordCollection(listWord);
        em.getTransaction().begin();
        em.persist(w);
        em.getTransaction().commit();
        em.close();
    }

    public static Word get(String description) {
        EntityManager em = new ConnectionFactory().getConnection();
        em.getTransaction().begin();

        String jpql = "select p from Word p where p.description = '" + description + "'";
        TypedQuery<Word> query = em.createQuery(jpql, Word.class);
        List<Word> results = query.getResultList();

        em.getTransaction().commit();
        em.close();
        
        if(!results.isEmpty()){
            return results.get(0);    
        } else {
            return null;
        }
        
    }
}
