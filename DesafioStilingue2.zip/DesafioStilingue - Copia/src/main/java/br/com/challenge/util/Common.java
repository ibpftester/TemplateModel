package br.com.challenge.util;

import java.util.ArrayList;
import java.util.List;

import br.com.challenge.web.crawler.GenerateJson;

public class Common {

	private static List<String> listA = new ArrayList<>();
	private static List<String> listB = new ArrayList<>();
	private static List<String> listC = new ArrayList<>();
	private static List<String> listD = new ArrayList<>();
	private static List<String> listE = new ArrayList<>();
	private static List<String> listF = new ArrayList<>();
	private static List<String> listG = new ArrayList<>();
	private static List<String> listH = new ArrayList<>();
	private static List<String> listI = new ArrayList<>();
	private static List<String> listJ = new ArrayList<>();
	private static List<String> listK = new ArrayList<>();
	private static List<String> listL = new ArrayList<>();
	private static List<String> listM = new ArrayList<>();
	private static List<String> listN = new ArrayList<>();
	private static List<String> listO = new ArrayList<>();
	private static List<String> listP = new ArrayList<>();
	private static List<String> listQ = new ArrayList<>();
	private static List<String> listR = new ArrayList<>();
	private static List<String> listS = new ArrayList<>();
	private static List<String> listT = new ArrayList<>();
	private static List<String> listU = new ArrayList<>();
	private static List<String> listV = new ArrayList<>();
	private static List<String> listX = new ArrayList<>();
	private static List<String> listY = new ArrayList<>();
	private static List<String> listW = new ArrayList<>();
	private static List<String> listZ = new ArrayList<>();
	private static List<String> list_ = new ArrayList<>();

	public static String encode(String originalWord) {
		return originalWord.replace("'", "").replace("\\", "").trim();
	}

	public static int getPosition(String originalWord) {
		switch (originalWord) {
		case "a":
			listA.add(originalWord);
			return 0;
		case "b":
			listB.add(originalWord);
			return 500;
		case "c":
			listC.add(originalWord);
			return 1000;
		case "d":
			listD.add(originalWord);
			return 1500;
		case "e":
			listE.add(originalWord);
			return 2000;
		case "f":
			listF.add(originalWord);
			return 2500;
		case "g":
			listG.add(originalWord);
			return 3000;
		case "h":
			listH.add(originalWord);
			return 3500;
		case "i":
			listI.add(originalWord);
			return 4000;
		case "j":
			listJ.add(originalWord);
			return 4500;
		case "k":
			listK.add(originalWord);
			return 5000;
		case "l":
			listL.add(originalWord);
			return 5500;
		case "m":
			listM.add(originalWord);
			return 6000;
		case "n":
			listN.add(originalWord);
			return 6500;
		case "o":
			listO.add(originalWord);
			return 7000;
		case "p":
			listP.add(originalWord);
			return 7500;
		case "q":
			listQ.add(originalWord);
			return 8000;
		case "r":
			listR.add(originalWord);
			return 8500;
		case "s":
			listS.add(originalWord);
			return 9000;
		case "t":
			listT.add(originalWord);
			return 9500;
		case "u":
			listU.add(originalWord);
			return 10000;
		case "v":
			listV.add(originalWord);
			return 10500;
		case "x":
			listX.add(originalWord);
			return 11000;
		case "w":
			listW.add(originalWord);
			return 11500;
		case "y":
			listY.add(originalWord);
			return 12000;
		case "z":
			listZ.add(originalWord);
			return 12500;
		default:
			list_.add(originalWord);
			return 13000;
		}
	}

	public static int getItensLetter(String originalWord) {
		switch (originalWord) {
		case "a":
			return listA.size();
		case "b":
			return listB.size();
		case "c":
			return listC.size();
		case "d":
			return listD.size();
		case "e":
			return listE.size();
		case "f":
			return listF.size();
		case "g":
			return listG.size();
		case "h":
			return listH.size();
		case "i":
			return listI.size();
		case "j":
			return listJ.size();
		case "k":
			return listK.size();
		case "l":
			return listL.size();
		case "m":
			return listM.size();
		case "n":
			return listN.size();
		case "o":
			return listO.size();
		case "p":
			return listP.size();
		case "q":
			return listQ.size();
		case "r":
			return listR.size();
		case "s":
			return listS.size();
		case "t":
			return listT.size();
		case "u":
			return listU.size();
		case "v":
			return listV.size();
		case "x":
			return listX.size();
		case "w":
			return listW.size();
		case "y":
			return listY.size();
		case "z":
			return listZ.size();
		default:
			return list_.size();
		}
	}

	public static List<Integer> getXY() {
		List<Integer> positions = new ArrayList<>();
		if (GenerateJson.qtde < GenerateJson.qtdDivide) {
			positions.add(GenerateJson.qtde*GenerateJson.qtdeY);
			positions.add(0);
		} else if (GenerateJson.qtde >= GenerateJson.qtdDivide && GenerateJson.qtde < GenerateJson.qtdDivide*2) {
			int teste = GenerateJson.qtde - GenerateJson.qtdDivide;
			positions.add(0);
			positions.add(teste*GenerateJson.qtdeY);
			GenerateJson.fixo = teste*GenerateJson.qtdeY;
		} else if (GenerateJson.qtde >= GenerateJson.qtdDivide*2 && GenerateJson.qtde < GenerateJson.qtdDivide*3) {
			int teste = GenerateJson.qtde - GenerateJson.qtdDivide*2;
			positions.add(teste*GenerateJson.qtdeY);
			positions.add(GenerateJson.fixo);
			GenerateJson.fixo2 = teste*GenerateJson.qtdeY;
		} else if (GenerateJson.qtde >= GenerateJson.qtdDivide*3 && GenerateJson.qtde < GenerateJson.qtdDivide*4) {
			int teste = GenerateJson.qtde - GenerateJson.qtdDivide*2;
			positions.add(GenerateJson.fixo2);
			positions.add(teste*GenerateJson.qtdeY);
			GenerateJson.fixo = teste*GenerateJson.qtdeY;
		} else {
			int teste = GenerateJson.qtde - GenerateJson.qtdDivide*4;
			positions.add(teste*GenerateJson.qtdeY);
			positions.add(GenerateJson.fixo);
		}
		return positions;
	}
}
