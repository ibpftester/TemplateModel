package br.com.challenge.web.crawler;

import java.util.ArrayList;
import java.util.List;

import br.com.challenge.model.bean.Word;
import br.com.challenge.model.dao.WordDAO;

public class CollectWords {

	public static List<Word> getCollection(List<String> wordsStringCollection) {
		List<Word> wordCollection = new ArrayList<Word>();

		for (String word : wordsStringCollection) {
			Word newWord = WordDAO.get(word);
			if (newWord != null) {
				wordCollection.add(newWord);
			} else {
				wordCollection.add(WordDAO.save(word, null));
			}
		}

		return wordCollection;
	}

}
